import { create } from 'zustand';
import { Faculty } from '../types';

interface FacultyState {
  faculty: Faculty[];
  addFaculty: (faculty: Omit<Faculty, 'id'>) => void;
  updateFacultyAvailability: (
    facultyId: string,
    availability: { day: string; slots: string[] }[]
  ) => void;
  removeFaculty: (id: string) => void;
}

export const useFacultyStore = create<FacultyState>((set) => ({
  faculty: [],
  addFaculty: (faculty) =>
    set((state) => ({
      faculty: [...state.faculty, { ...faculty, id: Date.now().toString() }],
    })),
  updateFacultyAvailability: (facultyId, availability) =>
    set((state) => ({
      faculty: state.faculty.map((f) =>
        f.id === facultyId ? { ...f, availability } : f
      ),
    })),
  removeFaculty: (id) =>
    set((state) => ({
      faculty: state.faculty.filter((f) => f.id !== id),
    })),
}));