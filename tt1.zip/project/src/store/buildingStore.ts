import { create } from 'zustand';
import { Building, Room } from '../types';

interface BuildingState {
  buildings: Building[];
  addBuilding: (name: string) => void;
  addRoom: (buildingId: string, room: Omit<Room, 'id' | 'buildingId'>) => void;
  removeBuilding: (id: string) => void;
  removeRoom: (buildingId: string, roomId: string) => void;
}

export const useBuildingStore = create<BuildingState>((set) => ({
  buildings: [],
  addBuilding: (name) =>
    set((state) => ({
      buildings: [
        ...state.buildings,
        { id: Date.now().toString(), name, rooms: [] },
      ],
    })),
  addRoom: (buildingId, room) =>
    set((state) => ({
      buildings: state.buildings.map((building) =>
        building.id === buildingId
          ? {
              ...building,
              rooms: [
                ...building.rooms,
                { ...room, id: Date.now().toString(), buildingId },
              ],
            }
          : building
      ),
    })),
  removeBuilding: (id) =>
    set((state) => ({
      buildings: state.buildings.filter((building) => building.id !== id),
    })),
  removeRoom: (buildingId, roomId) =>
    set((state) => ({
      buildings: state.buildings.map((building) =>
        building.id === buildingId
          ? {
              ...building,
              rooms: building.rooms.filter((room) => room.id !== roomId),
            }
          : building
      ),
    })),
}));