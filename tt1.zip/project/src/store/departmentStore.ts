import { create } from 'zustand';
import { Department, Subject } from '../types';

interface DepartmentState {
  departments: Department[];
  addDepartment: (name: string) => void;
  addSubject: (departmentId: string, subject: Omit<Subject, 'id' | 'departmentId'>) => void;
  removeDepartment: (id: string) => void;
  removeSubject: (departmentId: string, subjectId: string) => void;
}

export const useDepartmentStore = create<DepartmentState>((set) => ({
  departments: [],
  addDepartment: (name) =>
    set((state) => ({
      departments: [
        ...state.departments,
        { id: Date.now().toString(), name, subjects: [] },
      ],
    })),
  addSubject: (departmentId, subject) =>
    set((state) => ({
      departments: state.departments.map((dept) =>
        dept.id === departmentId
          ? {
              ...dept,
              subjects: [
                ...dept.subjects,
                { ...subject, id: Date.now().toString(), departmentId },
              ],
            }
          : dept
      ),
    })),
  removeDepartment: (id) =>
    set((state) => ({
      departments: state.departments.filter((dept) => dept.id !== id),
    })),
  removeSubject: (departmentId, subjectId) =>
    set((state) => ({
      departments: state.departments.map((dept) =>
        dept.id === departmentId
          ? {
              ...dept,
              subjects: dept.subjects.filter((subject) => subject.id !== subjectId),
            }
          : dept
      ),
    })),
}));