export interface User {
  id: string;
  name: string;
  role: 'student' | 'teacher' | 'admin';
}

export interface Course {
  id: string;
  name: string;
  teacher: string;
  duration: number;
}

export interface TimeSlot {
  day: string;
  time: string;
  course: Course;
  room: string;
}

export interface Department {
  id: string;
  name: string;
  subjects: Subject[];
}

export interface Subject {
  id: string;
  name: string;
  departmentId: string;
  credits: number;
}

export interface Building {
  id: string;
  name: string;
  rooms: Room[];
}

export interface Room {
  id: string;
  number: string;
  buildingId: string;
  capacity: number;
}

export interface Faculty {
  id: string;
  name: string;
  departmentId: string;
  subjects: string[]; // Subject IDs
  availability: {
    day: string;
    slots: string[];
  }[];
}