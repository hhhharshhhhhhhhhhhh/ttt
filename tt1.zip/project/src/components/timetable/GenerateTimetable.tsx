import React, { useState } from 'react';
import { Settings, Save } from 'lucide-react';

interface Constraint {
  id: string;
  type: string;
  value: string;
}

export function GenerateTimetable() {
  const [constraints, setConstraints] = useState<Constraint[]>([]);
  const [newConstraint, setNewConstraint] = useState({ type: 'room', value: '' });

  const addConstraint = () => {
    if (newConstraint.value.trim()) {
      setConstraints([
        ...constraints,
        { id: Date.now().toString(), ...newConstraint },
      ]);
      setNewConstraint({ type: 'room', value: '' });
    }
  };

  const removeConstraint = (id: string) => {
    setConstraints(constraints.filter((c) => c.id !== id));
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <Settings className="w-6 h-6 text-blue-600 mr-2" />
        <h2 className="text-xl font-semibold">Generate Timetable</h2>
      </div>

      <div className="space-y-6">
        <div className="space-y-4">
          <h3 className="font-medium text-gray-700">Add Constraints</h3>
          <div className="flex gap-4">
            <select
              className="flex-1 rounded border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
              value={newConstraint.type}
              onChange={(e) =>
                setNewConstraint({ ...newConstraint, type: e.target.value })
              }
            >
              <option value="room">Room Availability</option>
              <option value="teacher">Teacher Availability</option>
              <option value="subject">Subject Timing</option>
            </select>
            <input
              type="text"
              className="flex-1 rounded border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
              placeholder="Enter constraint value"
              value={newConstraint.value}
              onChange={(e) =>
                setNewConstraint({ ...newConstraint, value: e.target.value })
              }
            />
            <button
              onClick={addConstraint}
              className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              Add
            </button>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-medium text-gray-700">Current Constraints</h3>
          <div className="space-y-2">
            {constraints.map((constraint) => (
              <div
                key={constraint.id}
                className="flex items-center justify-between p-3 bg-gray-50 rounded"
              >
                <span>
                  {constraint.type}: {constraint.value}
                </span>
                <button
                  onClick={() => removeConstraint(constraint.id)}
                  className="text-red-500 hover:text-red-700"
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
        </div>

        <button className="w-full flex items-center justify-center gap-2 bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
          <Save className="w-5 h-5" />
          Generate Timetable
        </button>
      </div>
    </div>
  );
}