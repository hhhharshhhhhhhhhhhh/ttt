import React from 'react';
import { TimeSlot } from '../../types';

interface TimetableGridProps {
  timeSlots: TimeSlot[];
}

export function TimetableGrid({ timeSlots }: TimetableGridProps) {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const times = ['9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00'];

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white border border-gray-200">
        <thead>
          <tr>
            <th className="border p-2 bg-gray-50">Time</th>
            {days.map((day) => (
              <th key={day} className="border p-2 bg-gray-50">
                {day}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {times.map((time) => (
            <tr key={time}>
              <td className="border p-2 font-medium bg-gray-50">{time}</td>
              {days.map((day) => {
                const slot = timeSlots.find(
                  (slot) => slot.day === day && slot.time === time
                );
                return (
                  <td key={`${day}-${time}`} className="border p-2">
                    {slot ? (
                      <div className="bg-blue-100 p-2 rounded">
                        <div className="font-medium">{slot.course.name}</div>
                        <div className="text-sm text-gray-600">Room: {slot.room}</div>
                      </div>
                    ) : null}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}