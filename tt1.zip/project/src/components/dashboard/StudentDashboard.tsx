import React from 'react';
import { Calendar, Clock } from 'lucide-react';
import { TimetableGrid } from '../timetable/TimetableGrid';

export function StudentDashboard() {
  // Sample data - replace with actual API call
  const timeSlots = [
    {
      day: 'Monday',
      time: '9:00',
      course: { id: '1', name: 'Mathematics', teacher: 'John Doe', duration: 60 },
      room: '101',
    },
    {
      day: 'Monday',
      time: '10:00',
      course: { id: '2', name: 'Physics', teacher: 'Jane Smith', duration: 60 },
      room: '102',
    },
  ];

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">Student Dashboard</h1>
        <p className="text-gray-600">View your class schedule and upcoming sessions</p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex items-center mb-4">
          <Clock className="w-6 h-6 text-blue-600 mr-2" />
          <h2 className="text-xl font-semibold">Today's Schedule</h2>
        </div>
        <TimetableGrid timeSlots={timeSlots} />
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center mb-4">
          <Calendar className="w-6 h-6 text-blue-600 mr-2" />
          <h2 className="text-xl font-semibold">Weekly Overview</h2>
        </div>
        <div className="space-y-4">
          {/* Add weekly overview content here */}
        </div>
      </div>
    </div>
  );
}