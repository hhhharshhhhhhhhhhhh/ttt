import React from 'react';
import { GraduationCap, UserCog, Settings } from 'lucide-react';

interface RoleSelectorProps {
  onSelectRole: (role: 'student' | 'teacher' | 'admin') => void;
}

export function RoleSelector({ onSelectRole }: RoleSelectorProps) {
  return (
    <div className="w-full max-w-md">
      <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">Select Your Role</h2>
        <div className="grid grid-cols-3 gap-4">
          <button
            onClick={() => onSelectRole('student')}
            className="flex flex-col items-center p-6 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all"
          >
            <GraduationCap className="w-12 h-12 text-blue-600 mb-2" />
            <span className="font-semibold">Student</span>
          </button>
          <button
            onClick={() => onSelectRole('teacher')}
            className="flex flex-col items-center p-6 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all"
          >
            <UserCog className="w-12 h-12 text-blue-600 mb-2" />
            <span className="font-semibold">Teacher</span>
          </button>
          <button
            onClick={() => onSelectRole('admin')}
            className="flex flex-col items-center p-6 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all"
          >
            <Settings className="w-12 h-12 text-blue-600 mb-2" />
            <span className="font-semibold">Admin</span>
          </button>
        </div>
      </div>
    </div>
  );
}