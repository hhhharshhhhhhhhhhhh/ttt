import React, { useState } from 'react';
import { Settings, Save } from 'lucide-react';
import { useDepartmentStore } from '../../store/departmentStore';
import { useBuildingStore } from '../../store/buildingStore';
import { useFacultyStore } from '../../store/facultyStore';
import { TimetableGrid } from '../timetable/TimetableGrid';

export function TimetableGeneration() {
  const { departments } = useDepartmentStore();
  const { buildings } = useBuildingStore();
  const { faculty } = useFacultyStore();

  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedRoom, setSelectedRoom] = useState('');
  const [selectedFaculty, setSelectedFaculty] = useState('');
  const [selectedDay, setSelectedDay] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [generatedTimeSlots, setGeneratedTimeSlots] = useState([]);

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const times = ['9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00'];

  const handleGenerateTimetable = () => {
    // Add timetable generation logic here
    // This would typically involve the genetic algorithm
    // For now, we'll just add the selected slot
    if (selectedDepartment && selectedSubject && selectedRoom && selectedFaculty && selectedDay && selectedTime) {
      const newSlot = {
        day: selectedDay,
        time: selectedTime,
        course: {
          id: selectedSubject,
          name: departments
            .find(d => d.id === selectedDepartment)
            ?.subjects.find(s => s.id === selectedSubject)?.name || '',
          teacher: faculty.find(f => f.id === selectedFaculty)?.name || '',
          duration: 60
        },
        room: selectedRoom
      };
      setGeneratedTimeSlots([...generatedTimeSlots, newSlot]);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center mb-6">
          <Settings className="w-6 h-6 text-blue-600 mr-2" />
          <h2 className="text-xl font-semibold">Generate Timetable</h2>
        </div>

        <div className="grid grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Department</label>
              <select
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
                value={selectedDepartment}
                onChange={(e) => {
                  setSelectedDepartment(e.target.value);
                  setSelectedSubject('');
                }}
              >
                <option value="">Select Department</option>
                {departments.map((dept) => (
                  <option key={dept.id} value={dept.id}>
                    {dept.name}
                  </option>
                ))}
              </select>
            </div>

            {selectedDepartment && (
              <div>
                <label className="block text-sm font-medium text-gray-700">Subject</label>
                <select
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
                  value={selectedSubject}
                  onChange={(e) => setSelectedSubject(e.target.value)}
                >
                  <option value="">Select Subject</option>
                  {departments
                    .find((d) => d.id === selectedDepartment)
                    ?.subjects.map((subject) => (
                      <option key={subject.id} value={subject.id}>
                        {subject.name}
                      </option>
                    ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700">Room</label>
              <select
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
                value={selectedRoom}
                onChange={(e) => setSelectedRoom(e.target.value)}
              >
                <option value="">Select Room</option>
                {buildings.flatMap((building) =>
                  building.rooms.map((room) => (
                    <option key={room.id} value={room.number}>
                      {building.name} - Room {room.number}
                    </option>
                  ))
                )}
              </select>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Faculty</label>
              <select
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
                value={selectedFaculty}
                onChange={(e) => setSelectedFaculty(e.target.value)}
              >
                <option value="">Select Faculty</option>
                {faculty
                  .filter((f) => f.departmentId === selectedDepartment)
                  .map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name}
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Day</label>
              <select
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
                value={selectedDay}
                onChange={(e) => setSelectedDay(e.target.value)}
              >
                <option value="">Select Day</option>
                {days.map((day) => (
                  <option key={day} value={day}>
                    {day}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Time</label>
              <select
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
                value={selectedTime}
                onChange={(e) => setSelectedTime(e.target.value)}
              >
                <option value="">Select Time</option>
                {times.map((time) => (
                  <option key={time} value={time}>
                    {time}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="mt-6">
          <button
            onClick={handleGenerateTimetable}
            className="w-full flex items-center justify-center gap-2 bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
          >
            <Save className="w-5 h-5" />
            Generate Timetable
          </button>
        </div>
      </div>

      {generatedTimeSlots.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Generated Timetable</h2>
          <TimetableGrid timeSlots={generatedTimeSlots} />
        </div>
      )}
    </div>
  );
}