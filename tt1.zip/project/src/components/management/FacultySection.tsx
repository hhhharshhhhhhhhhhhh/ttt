import React, { useState } from 'react';
import { Users, Plus, Trash2 } from 'lucide-react';
import { useFacultyStore } from '../../store/facultyStore';
import { useDepartmentStore } from '../../store/departmentStore';

export function FacultySection() {
  const { faculty, addFaculty, removeFaculty } = useFacultyStore();
  const { departments } = useDepartmentStore();
  const [newFaculty, setNewFaculty] = useState({
    name: '',
    departmentId: '',
    subjects: [] as string[],
    availability: [] as { day: string; slots: string[] }[],
  });

  const handleAddFaculty = () => {
    if (newFaculty.name.trim() && newFaculty.departmentId) {
      addFaculty(newFaculty);
      setNewFaculty({
        name: '',
        departmentId: '',
        subjects: [],
        availability: [],
      });
    }
  };

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const timeSlots = [
    '9:00', '10:00', '11:00', '12:00',
    '13:00', '14:00', '15:00', '16:00'
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <Users className="w-6 h-6 text-blue-600 mr-2" />
        <h2 className="text-xl font-semibold">Faculty Management</h2>
      </div>

      <div className="space-y-6">
        {/* Add Faculty Form */}
        <div className="space-y-4">
          <h3 className="font-medium text-gray-700">Add Faculty</h3>
          <div className="space-y-4">
            <input
              type="text"
              className="w-full rounded border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
              placeholder="Faculty Name"
              value={newFaculty.name}
              onChange={(e) =>
                setNewFaculty({ ...newFaculty, name: e.target.value })
              }
            />
            <select
              className="w-full rounded border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
              value={newFaculty.departmentId}
              onChange={(e) =>
                setNewFaculty({ ...newFaculty, departmentId: e.target.value })
              }
            >
              <option value="">Select Department</option>
              {departments.map((dept) => (
                <option key={dept.id} value={dept.id}>
                  {dept.name}
                </option>
              ))}
            </select>
            {newFaculty.departmentId && (
              <div className="space-y-2">
                <label className="block font-medium text-gray-700">
                  Select Subjects
                </label>
                <div className="space-y-2">
                  {departments
                    .find((d) => d.id === newFaculty.departmentId)
                    ?.subjects.map((subject) => (
                      <label
                        key={subject.id}
                        className="flex items-center space-x-2"
                      >
                        <input
                          type="checkbox"
                          checked={newFaculty.subjects.includes(subject.id)}
                          onChange={(e) => {
                            const subjects = e.target.checked
                              ? [...newFaculty.subjects, subject.id]
                              : newFaculty.subjects.filter(
                                  (id) => id !== subject.id
                                );
                            setNewFaculty({ ...newFaculty, subjects });
                          }}
                        />
                        <span>{subject.name}</span>
                      </label>
                    ))}
                </div>
              </div>
            )}
            <button
              onClick={handleAddFaculty}
              className="w-full px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 flex items-center justify-center"
            >
              <Plus className="w-4 h-4 mr-1" />
              Add Faculty
            </button>
          </div>
        </div>

        {/* Faculty List */}
        <div className="space-y-4">
          <h3 className="font-medium text-gray-700">Faculty Members</h3>
          <div className="space-y-4">
            {faculty.map((f) => (
              <div key={f.id} className="border rounded-lg p-4 space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-semibold">{f.name}</h4>
                    <p className="text-sm text-gray-600">
                      Department:{' '}
                      {departments.find((d) => d.id === f.departmentId)?.name}
                    </p>
                  </div>
                  <button
                    onClick={() => removeFaculty(f.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="text-sm">
                  <strong>Subjects:</strong>
                  <div className="mt-1">
                    {f.subjects
                      .map(
                        (subjectId) =>
                          departments
                            .find((d) => d.id === f.departmentId)
                            ?.subjects.find((s) => s.id === subjectId)?.name
                      )
                      .join(', ')}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}