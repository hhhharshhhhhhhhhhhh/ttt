import React, { useState } from 'react';
import { Building as BuildingIcon, Plus, Trash2 } from 'lucide-react';
import { useBuildingStore } from '../../store/buildingStore';

export function BuildingSection() {
  const { buildings, addBuilding, addRoom, removeBuilding, removeRoom } =
    useBuildingStore();
  const [newBuilding, setNewBuilding] = useState('');
  const [newRoom, setNewRoom] = useState({ number: '', capacity: 0 });
  const [selectedBuilding, setSelectedBuilding] = useState<string | null>(null);

  const handleAddBuilding = () => {
    if (newBuilding.trim()) {
      addBuilding(newBuilding);
      setNewBuilding('');
    }
  };

  const handleAddRoom = () => {
    if (selectedBuilding && newRoom.number.trim()) {
      addRoom(selectedBuilding, newRoom);
      setNewRoom({ number: '', capacity: 0 });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <BuildingIcon className="w-6 h-6 text-blue-600 mr-2" />
        <h2 className="text-xl font-semibold">Building Management</h2>
      </div>

      <div className="space-y-6">
        {/* Add Building Form */}
        <div className="space-y-4">
          <h3 className="font-medium text-gray-700">Add Building</h3>
          <div className="flex gap-4">
            <input
              type="text"
              className="flex-1 rounded border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
              placeholder="Building Name"
              value={newBuilding}
              onChange={(e) => setNewBuilding(e.target.value)}
            />
            <button
              onClick={handleAddBuilding}
              className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 flex items-center"
            >
              <Plus className="w-4 h-4 mr-1" />
              Add
            </button>
          </div>
        </div>

        {/* Add Room Form */}
        {buildings.length > 0 && (
          <div className="space-y-4">
            <h3 className="font-medium text-gray-700">Add Room</h3>
            <div className="space-y-4">
              <select
                className="w-full rounded border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
                value={selectedBuilding || ''}
                onChange={(e) => setSelectedBuilding(e.target.value)}
              >
                <option value="">Select Building</option>
                {buildings.map((building) => (
                  <option key={building.id} value={building.id}>
                    {building.name}
                  </option>
                ))}
              </select>
              <div className="flex gap-4">
                <input
                  type="text"
                  className="flex-1 rounded border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
                  placeholder="Room Number"
                  value={newRoom.number}
                  onChange={(e) =>
                    setNewRoom({ ...newRoom, number: e.target.value })
                  }
                />
                <input
                  type="number"
                  className="w-32 rounded border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
                  placeholder="Capacity"
                  value={newRoom.capacity}
                  onChange={(e) =>
                    setNewRoom({
                      ...newRoom,
                      capacity: parseInt(e.target.value) || 0,
                    })
                  }
                />
                <button
                  onClick={handleAddRoom}
                  className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 flex items-center"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Building List */}
        <div className="space-y-4">
          <h3 className="font-medium text-gray-700">Buildings</h3>
          <div className="space-y-4">
            {buildings.map((building) => (
              <div
                key={building.id}
                className="border rounded-lg p-4 space-y-4"
              >
                <div className="flex justify-between items-center">
                  <h4 className="font-semibold">{building.name}</h4>
                  <button
                    onClick={() => removeBuilding(building.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="space-y-2">
                  {building.rooms.map((room) => (
                    <div
                      key={room.id}
                      className="flex justify-between items-center bg-gray-50 p-2 rounded"
                    >
                      <span>
                        Room {room.number} (Capacity: {room.capacity})
                      </span>
                      <button
                        onClick={() => removeRoom(building.id, room.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}