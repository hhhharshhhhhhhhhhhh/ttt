import React, { useState } from 'react';
import { Building, Plus, Trash2 } from 'lucide-react';
import { useDepartmentStore } from '../../store/departmentStore';

export function DepartmentSection() {
  const { departments, addDepartment, addSubject, removeDepartment, removeSubject } =
    useDepartmentStore();
  const [newDepartment, setNewDepartment] = useState('');
  const [newSubject, setNewSubject] = useState({ name: '', credits: 3 });
  const [selectedDepartment, setSelectedDepartment] = useState<string | null>(null);

  const handleAddDepartment = () => {
    if (newDepartment.trim()) {
      addDepartment(newDepartment);
      setNewDepartment('');
    }
  };

  const handleAddSubject = () => {
    if (selectedDepartment && newSubject.name.trim()) {
      addSubject(selectedDepartment, newSubject);
      setNewSubject({ name: '', credits: 3 });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <Building className="w-6 h-6 text-blue-600 mr-2" />
        <h2 className="text-xl font-semibold">Department Management</h2>
      </div>

      <div className="space-y-6">
        {/* Add Department Form */}
        <div className="space-y-4">
          <h3 className="font-medium text-gray-700">Add Department</h3>
          <div className="flex gap-4">
            <input
              type="text"
              className="flex-1 rounded border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
              placeholder="Department Name"
              value={newDepartment}
              onChange={(e) => setNewDepartment(e.target.value)}
            />
            <button
              onClick={handleAddDepartment}
              className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 flex items-center"
            >
              <Plus className="w-4 h-4 mr-1" />
              Add
            </button>
          </div>
        </div>

        {/* Add Subject Form */}
        {departments.length > 0 && (
          <div className="space-y-4">
            <h3 className="font-medium text-gray-700">Add Subject</h3>
            <div className="space-y-4">
              <select
                className="w-full rounded border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
                value={selectedDepartment || ''}
                onChange={(e) => setSelectedDepartment(e.target.value)}
              >
                <option value="">Select Department</option>
                {departments.map((dept) => (
                  <option key={dept.id} value={dept.id}>
                    {dept.name}
                  </option>
                ))}
              </select>
              <div className="flex gap-4">
                <input
                  type="text"
                  className="flex-1 rounded border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
                  placeholder="Subject Name"
                  value={newSubject.name}
                  onChange={(e) =>
                    setNewSubject({ ...newSubject, name: e.target.value })
                  }
                />
                <input
                  type="number"
                  className="w-24 rounded border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200"
                  placeholder="Credits"
                  value={newSubject.credits}
                  onChange={(e) =>
                    setNewSubject({
                      ...newSubject,
                      credits: parseInt(e.target.value) || 0,
                    })
                  }
                />
                <button
                  onClick={handleAddSubject}
                  className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 flex items-center"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Department List */}
        <div className="space-y-4">
          <h3 className="font-medium text-gray-700">Departments</h3>
          <div className="space-y-4">
            {departments.map((dept) => (
              <div
                key={dept.id}
                className="border rounded-lg p-4 space-y-4"
              >
                <div className="flex justify-between items-center">
                  <h4 className="font-semibold">{dept.name}</h4>
                  <button
                    onClick={() => removeDepartment(dept.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="space-y-2">
                  {dept.subjects.map((subject) => (
                    <div
                      key={subject.id}
                      className="flex justify-between items-center bg-gray-50 p-2 rounded"
                    >
                      <span>
                        {subject.name} ({subject.credits} credits)
                      </span>
                      <button
                        onClick={() => removeSubject(dept.id, subject.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}