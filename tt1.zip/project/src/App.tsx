import React, { useState } from 'react';
import { useAuthStore } from './store/authStore';
import { RoleSelector } from './components/auth/RoleSelector';
import { LoginForm } from './components/auth/LoginForm';
import { TeacherDashboard } from './components/dashboard/TeacherDashboard';
import { StudentDashboard } from './components/dashboard/StudentDashboard';
import { ManagementDashboard } from './components/management/ManagementDashboard';

function App() {
  const { isAuthenticated, user } = useAuthStore();
  const [selectedRole, setSelectedRole] = useState<'student' | 'teacher' | 'admin' | null>(null);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        {selectedRole ? (
          <LoginForm role={selectedRole} onBack={() => setSelectedRole(null)} />
        ) : (
          <RoleSelector onSelectRole={setSelectedRole} />
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {user?.role === 'teacher' && <TeacherDashboard />}
      {user?.role === 'student' && <StudentDashboard />}
      {user?.role === 'admin' && <ManagementDashboard />}
    </div>
  );
}